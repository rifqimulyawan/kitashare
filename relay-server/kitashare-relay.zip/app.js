// Passenger entry point for Hostinger hPanel
// This file is required by Phusion Passenger to start the Node.js app
require('./dist/index.js');
